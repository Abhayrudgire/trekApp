import { Component } from "@angular/core";

@Component({
  selector: "contact-list",
  templateUrl: "../contactList/contactList.component.html"
})
export class ContactList {}
